<p align="center"><img src="images/02.png" alt="MultiGen"></p>
<div align="center" style="margin-top: 0;">
   <p>Don't Skid 👀</p>
</div>
<em><h5 align="center">(Programming Language - Python 3)</h5></em>
<p align="center">
<a href="#"><img alt="MultiGen forks" src="https://img.shields.io/github/forks/BlackSnowDot/MultiAccountGenerator?style=for-the-badge"></a>
<a href="#"><img alt="Repo stars" src="https://img.shields.io/github/stars/BlackSnowDot/MultiAccountGenerator?style=for-the-badge&color=yellow"></a>
<a href="#"><img alt="MultiGen License" src="https://img.shields.io/github/license/BlackSnowDot/MultiAccountGenerator?color=orange&style=for-the-badge"></a>
<a href="https://github.com/BlackSnowDot/MultiAccountGenerator/issues"><img alt="issues" src="https://img.shields.io/github/issues/BlackSnowDot/MultiAccountGenerator?color=purple&style=for-the-badge"></a>
<p align="center"><img src="https://views.whatilearened.today/views/github/BlackSnowDot/MultiAccountGenerator.svg" width="80px" height="28px" alt="View"></p>

---

<p align="center"><img src="images/01.png" width="1040" alt="outlook"></p>

## 📝 Document
### Don't Use Vpn or Proxy!
**Install Requirements**

```
pip3 install -r requirements.txt
```
Also you can use install.bat

**Run Script**
```shell
python3 generator.py
```
Also you can use run.bat

### Note: You Can Change Something's in `config.json`
### Also, You Can see some Screenshots from [Here](https://github.com/BlackSnowDot/MultiAccountGenerator/tree/main/screenshots)

Maybe This Video Help You


https://user-images.githubusercontent.com/95581741/199072993-e7705478-e68d-4074-b3b3-8d7c5dce85b7.mp4



---
## 📝 ToDo

1. [ ] More Websites
2. [x] Async

<h6 align="center" style="color: #25DCF9">You Can't Give me 1 str :(?</h6>
